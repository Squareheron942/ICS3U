public interface Pass {
    Pixel[][] render(Pixel[][] in);
}
