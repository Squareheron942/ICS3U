class MaterialProperty {
    Color color;
    Texture tex;
    float val;
    String name;
    String type;

    MaterialProperty (Color color) {
        
    }
}